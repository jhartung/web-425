/*
============================================
; Title: Assignment 1.4 - TypeScript
; Author: Professor Krasso
; Date: 24 May 2022
; Modified By: Joel Hartung
; Description: Assignment 1.4 - TypeScript
; Code Attribution: Additional code from WEB 425 Exercise 1.4 documentation & video
;===========================================
*/

export interface IPerson {
    firstName: string;
    lastName: string;
}